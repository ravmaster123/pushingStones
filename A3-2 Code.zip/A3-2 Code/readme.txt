Welcome to Pushing Stones!

For the best gaming experience, please change you Ed into dark mode, which can be found in the setting---appearance.

To run the game, run the file main.py by typing the following into the terminal: "python3 main.py"

The terminal size can be adjusted accordingly by the user if they wish by dragging the window up and down. 

Since this is a two player game, one can play with a friend either on the same computer or different ones by adding them as a user on this
ed workspace. Click ">_" on the top right and make sure both players enter the same terminal and they can both type into the terminal
in real time!

We hope you enjoy! ( ͡° ͜ʖ ͡°)

